import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit{
  myData={name:'',price:'',quantity:'',category:'',description:'',img:''}
  constructor(private pser:ProductService,private router:Router){}

  ngOnInit(): void {}
  postdata(){
    this.pser.postData(this.myData)
    .subscribe(res=>{
      if(res){
        alert("Data Added");
        this.router.navigate(['/']);
      }
    })
  }
}
